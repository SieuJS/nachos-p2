#include"syscall.h"

int main() 
{
	CreateFile("test_createfile.txt");
	return 0;
}
